<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Informasi Lowongan Pekerjaan</h2>

  <!-- Search Form -->
  <form method="GET" action="<?php echo e(route('job.search')); ?>" class="mb-5">
    <div class="input-group ">
        <input type="text" name="search" class="form-control" placeholder="Cari lowongan..." value="<?php echo e(request()->query('search')); ?>">
        <button class="btn btn-primary" type="submit">Cari</button>
    </div>
</form>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $Loker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 mb-4">
                <div class="card hover-card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->jabatan); ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted"><?php echo e($item->perusahaan->nama); ?></h6>
                        <p class="card-text">
                            <i class="fas fa-clock"></i> <?php echo e($item->jenis_waktu_pekerjaan); ?><br>
                            <i class="fas fa-map-marker-alt"></i> <?php echo e($item->perusahaan->alamat); ?><br>
                            <i class="fas fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($item->waktu)->format('j M Y H:i')); ?> sampai <?php echo e($item->tanggal_akhir); ?><br>
                        </p>
                        <p class="card-text"><?php echo e($item->deskripsi); ?></p>
                        <a href="<?php echo e(route('job.detail', $item->id_lowongan_pekerjaan)); ?>" class="btn btn-primary">Detail</a>
                        <a href="#" class="btn btn-outline-primary ml-2" data-bs-toggle="modal" data-bs-target="#lamarModal">Lamar</a>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-info">
                    <strong>Belum ada lowongan</strong>
                </div>
            </div>
        <?php endif; ?>

         <!-- Pagination Links -->
    <div class="d-flex justify-content-center">
        <?php echo e($Loker->links()); ?>

    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<style>
    .card {
        height: 100%;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .card-body {
        display: flex;
        flex-direction: column;
    }
    .card-text {
        flex-grow: 1;
    }
    .fas {
        width: 20px;
        text-align: center;
        margin-right: 5px;
    }
    .hover-card:hover {
        transform: translateY(-10px);
        box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
    }
    .btn-outline-primary.ml-2 {
        margin-top: 0.5rem;
    }
</style>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BKK2\resources\views/dashboardAlumni.blade.php ENDPATH**/ ?>