<?php $__env->startSection('content'); ?>

<!-- Fonts and icons -->
<script src="<?php echo e(asset('BKK2/assets/js/plugin/webfont/webfont.min.js')); ?>"></script>
<script>
    WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
            families: [
                "Font Awesome 5 Solid",
                "Font Awesome 5 Regular",
                "Font Awesome 5 Brands",
                "simple-line-icons",
            ],
            urls: ["<?php echo e(asset('BKK2/assets/css/fonts.min.css')); ?>"],
        },
        active: function () {
            sessionStorage.fonts = true;
        },
    });
</script>

<!-- CSS Files -->
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/plugins.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/kaiadmin.min.css')); ?>" />

<!-- CSS Just for demo purpose, don't include it in your project -->
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/demo.css')); ?>" />

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Akun Pengguna</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="icon-home"></i>
                    </a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Basic</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="alumni-table">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($us->username); ?></td>
                                        <td><?php echo e($us->role); ?></td>
                                        <td>
                                            <!-- Button to trigger the modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#aktivitasPenggunaModal<?php echo e($us->username); ?>">
                                                Pemantauan
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="aktivitasPenggunaModal<?php echo e($us->username); ?>" tabindex="-1" aria-labelledby="aktivitasPenggunaModalLabel<?php echo e($us->username); ?>" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="aktivitasPenggunaModalLabel<?php echo e($us->username); ?>">Aktivitas Pengguna: <?php echo e($us->username); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="table-responsive">
                                                                <table class="table table-striped">
                                                                    <thead>
                                                                        <tr>
                                                                            <th scope="col">Waktu</th>
                                                                            <th scope="col">Keterangan</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <!-- Pastikan Anda mem-filter aktivitas berdasarkan pengguna -->
                                                                        <?php $__currentLoopData = $aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Jika Anda memiliki relasi -->
                                                                        <tr>
                                                                            <td><?php echo e($ak->tanggal); ?></td>
                                                                            <td><?php echo e($ak->keterangan); ?></td>
                                                                        </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BKK2\resources\views/Akunpengguna.blade.php ENDPATH**/ ?>