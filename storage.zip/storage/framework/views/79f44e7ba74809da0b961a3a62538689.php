<?php $__env->startSection('content'); ?>

<!-- Fonts and icons -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="<?php echo e(asset('BKK2/assets/js/plugin/webfont/webfont.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.5.2/bootbox.min.js"></script>
<script>
  WebFont.load({
    google: { families: ["Public Sans:300,400,500,600,700"] },
    custom: {
      families: [
        "Font Awesome 5 Solid",
        "Font Awesome 5 Regular",
        "Font Awesome 5 Brands",
        "simple-line-icons",
      ],
      urls: ["<?php echo e(asset('BKK2/assets/css/fonts.min.css')); ?>"],
    },
    active: function () {
      sessionStorage.fonts = true;
    },
  });
</script>
<script>
    <?php if(session('success')): ?>
    $.notify({
        title: '<strong>Success</strong>',
        message: "<?php echo e(session('success')); ?>"
    },{
        type: 'success',
        placement: {
            from: "top",
            align: "right"
        },
        delay: 5000,
        timer: 1000
    });
<?php endif; ?>

</script>

<!-- CSS Files -->
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/plugins.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/kaiadmin.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('BKK2/assets/css/demo.css')); ?>" />

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>




<div class="container">
    <div class="page-inner">
        <div class="page-header">
            <h3 class="fw-bold mb-3">Data Loker</h3>
            <ul class="breadcrumbs mb-3">
                <li class="nav-home">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="icon-home"></i>
                    </a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Basic</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addJobModal">Tambah Data Loker</button>
                            <table id="basic-datatables" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Jabatan</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="alumni-table">
                                    <?php $__currentLoopData = $loker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lowongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($lowongan->jabatan); ?></td>
                                        <td><?php echo e($lowongan->status); ?></td>
                                        <td>
                                            <!-- Button to Open the Modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#detailModal<?php echo e($lowongan->id_lowongan_pekerjaan); ?>">
                                                Lihat Detail
                                            </button>

                                            <!-- The Modal -->
                                            <div class="modal fade" id="detailModal<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" tabindex="-1" data-bs-backdrop="false" aria-labelledby="detailModalLabel<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="detailModalLabel<?php echo e($lowongan->id_lowongan_pekerjaan); ?>">Detail Lowongan: <?php echo e($lowongan->jabatan); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p><strong>Jabatan:</strong> <?php echo e($lowongan->jabatan); ?></p>
                                                            <p><strong>Jenis Waktu Pekerjaan:</strong> <?php echo e($lowongan->jenis_waktu_pekerjaan); ?></p>
                                                            <p><strong>Deskripsi:</strong> <?php echo e($lowongan->deskripsi); ?></p>
                                                            <p><strong>Tanggal Akhir:</strong> <?php echo e($lowongan->tanggal_akhir); ?></p>
                                                            <p><strong>Status:</strong> <?php echo e($lowongan->status); ?></p>
                                                            <?php if(file_exists(public_path("alasan_lowongan_{$lowongan->id_lowongan_pekerjaan}.txt"))): ?>
                                                                <?php
                                                                    $alasan = file_get_contents(public_path("alasan_lowongan_{$lowongan->id_lowongan_pekerjaan}.txt"));
                                                                ?>
                                                                <div class="alert alert-info">
                                                                    <strong>Alasan Tidak Dipublikasi:</strong> <?php echo e($alasan); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Button to Open the Edit Modal -->
                                            <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($lowongan->id_lowongan_pekerjaan); ?>">
                                                Edit
                                            </button>

                                            <!-- The Edit Modal -->
                                            <div class="modal fade" id="editModal<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" tabindex="-1" data-bs-backdrop="false" aria-labelledby="editModalLabel<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editModalLabel<?php echo e($lowongan->id_lowongan_pekerjaan); ?>">Edit Lowongan: <?php echo e($lowongan->jabatan); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="<?php echo e(route('lowongan.update', $lowongan->id_lowongan_pekerjaan)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="modal-body">
                                                                <div class="mb-3">
                                                                    <label for="jabatan<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" class="form-label">Jabatan Pekerjaan</label>
                                                                    <input class="form-control" type="text" id="jabatan<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" name="jabatan" value="<?php echo e($lowongan->jabatan); ?>" placeholder="Jabatan pekerjaan" autofocus required />
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="jenis_waktu_pekerjaan<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" class="form-label">Jenis Waktu Pekerjaan</label>
                                                                    <select class="form-control" id="jenis_waktu_pekerjaan<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" name="jenis_waktu_pekerjaan" required>
                                                                        <option value="">Pilih Jenis Waktu Pekerjaan</option>
                                                                        <option value="Waktu Kerja Standar (Full-Time)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Standar (Full-Time)' ? 'selected' : ''); ?>>Waktu Kerja Standar (Full-Time)</option>
                                                                        <option value="Waktu Kerja Paruh Waktu (Part-Time)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Paruh Waktu (Part-Time)' ? 'selected' : ''); ?>>Waktu Kerja Paruh Waktu (Part-Time)</option>
                                                                        <option value="Waktu Kerja Fleksibel (Flexible Hours)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Fleksibel (Flexible Hours)' ? 'selected' : ''); ?>>Waktu Kerja Fleksibel (Flexible Hours)</option>
                                                                        <option value="Shift Kerja (Shift Work)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Shift Kerja (Shift Work)' ? 'selected' : ''); ?>>Shift Kerja (Shift Work)</option>
                                                                        <option value="Waktu Kerja Bergilir (Rotating Shift)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Bergilir (Rotating Shift)' ? 'selected' : ''); ?>>Waktu Kerja Bergilir (Rotating Shift)</option>
                                                                        <option value="Waktu Kerja Jarak Jauh (Remote work)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Jarak Jauh (Remote work)' ? 'selected' : ''); ?>>Waktu Kerja Jarak Jauh (Remote work)</option>
                                                                        <option value="Waktu Kerja Kontrak (Contract Work)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Kontrak (Contract Work)' ? 'selected' : ''); ?>>Waktu Kerja Kontrak (Contract Work)</option>
                                                                        <option value="Waktu Kerja Proyek (Project-Based Work)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Proyek (Project-Based Work)' ? 'selected' : ''); ?>>Waktu Kerja Proyek (Project-Based Work)</option>
                                                                        <option value="Waktu Kerja Musiman (Seasonal Work)" <?php echo e($lowongan->jenis_waktu_pekerjaan == 'Waktu Kerja Musiman (Seasonal Work)' ? 'selected' : ''); ?>>Waktu Kerja Musiman (Seasonal Work)</option>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="deskripsi<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" class="form-label">Deskripsi Pekerjaan</label>
                                                                    <textarea class="form-control" id="deskripsi<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" name="deskripsi" rows="4" required><?php echo e($lowongan->deskripsi); ?></textarea>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="tanggal_akhir<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" class="form-label">Tanggal Akhir Lowongan</label>
                                                                    <input class="form-control" type="date" id="tanggal_akhir<?php echo e($lowongan->id_lowongan_pekerjaan); ?>" name="tanggal_akhir" value="<?php echo e($lowongan->tanggal_akhir); ?>" required />
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary">Update</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal untuk menambah data loker -->
<div class="modal fade" id="addJobModal" tabindex="-1" data-bs-backdrop="false" aria-labelledby="addJobModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addJobModalLabel">Tambah Data Loker</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('lowongan.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="jabatan" class="form-label">Jabatan Pekerjaan</label>
                        <input class="form-control" type="text" id="jabatan" name="jabatan" placeholder="Jabatan pekerjaan" autofocus required />
                    </div>
                    <div class="mb-3">
                        <label for="jenis_waktu_pekerjaan" class="form-label">Jenis Waktu Pekerjaan</label>
                        <select class="form-control" id="jenis_waktu_pekerjaan" name="jenis_waktu_pekerjaan" required>
                            <option value="" selected>Pilih Jenis Waktu Pekerjaan</option>
                            <option value="Waktu Kerja Standar (Full-Time)" >Waktu Kerja Standar (Full-Time)</option>
                            <option value="Waktu Kerja Paruh Waktu (Part-Time)">Waktu Kerja Paruh Waktu (Part-Time)</option>
                            <option value="Waktu Kerja Fleksibel (Flexible Hours)" >Waktu Kerja Fleksibel (Flexible Hours)</option>
                            <option value="Shift Kerja (Shift Work)">Shift Kerja (Shift Work)</option>
                            <option value="Waktu Kerja Bergilir (Rotating Shift)">Waktu Kerja Bergilir (Rotating Shift)</option>
                            <option value="Waktu Kerja Jarak Jauh (Remote work)" >Waktu Kerja Jarak Jauh (Remote work)</option>
                            <option value="Waktu Kerja Kontrak (Contract Work)">Waktu Kerja Kontrak (Contract Work)</option>
                            <option value="Waktu Kerja Proyek (Project-Based Work)">Waktu Kerja Proyek (Project-Based Work)</option>
                            <option value="Waktu Kerja Musiman (Seasonal Work)">Waktu Kerja Musiman (Seasonal Work)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="deskripsi" class="form-label">Deskripsi Pekerjaan</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal_akhir" class="form-label">Tanggal Akhir Lowongan</label>
                        <input class="form-control" type="date" id="tanggal_akhir" name="tanggal_akhir" required />
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!--   Core JS Files   -->
<script src="<?php echo e(asset('BKK2/assets/js/core/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('BKK2/assets/js/core/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('BKK2/assets/js/core/bootstrap.min.js')); ?>"></script>

<!-- jQuery Scrollbar -->
<script src="<?php echo e(asset('BKK2/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>
<!-- Datatables -->
<script src="<?php echo e(asset('BKK2/assets/js/plugin/datatables/datatables.min.js')); ?>"></script>
<!-- Kaiadmin JS -->
<script src="<?php echo e(asset('BKK2/assets/js/kaiadmin.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('#basic-datatables').DataTable();
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BKK2\resources\views/dataLoker.blade.php ENDPATH**/ ?>